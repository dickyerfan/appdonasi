#
# TABLE STRUCTURE FOR: detail_taqur
#

DROP TABLE IF EXISTS `detail_taqur`;

CREATE TABLE `detail_taqur` (
  `id_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `id_penabung` int(11) NOT NULL,
  `jml_tabungan` varchar(100) NOT NULL,
  `status_tabungan` int(1) NOT NULL DEFAULT 1,
  `tgl_tabungan` date NOT NULL,
  `nama_user` varchar(100) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `tgl_update` datetime DEFAULT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `id_penabung` (`id_penabung`),
  CONSTRAINT `detail_taqur_ibfk_1` FOREIGN KEY (`id_penabung`) REFERENCES `taqur` (`id_penabung`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4;

INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (1, 7, '100000', 1, '2022-12-20', 'Admin', '2022-12-20 06:03:24', '2022-12-20 06:03:24');
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (2, 9, '500000', 1, '2022-12-14', 'Admin', '2022-12-20 06:39:11', '2022-12-20 06:39:11');
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (3, 10, '75000', 1, '2022-12-16', 'Admin', '2022-12-20 06:40:17', '2022-12-20 06:40:17');
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (4, 10, '75000', 1, '2022-12-20', 'Admin', '2022-12-20 06:41:09', '2022-12-20 06:41:09');
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (5, 7, '50000', 1, '2022-12-20', 'Dicky Erfan Septiono', '2022-12-20 14:00:41', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (6, 9, '75000', 1, '2022-12-20', 'Dicky Erfan Septiono', '2022-12-20 14:02:56', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (7, 7, '50000', 1, '2022-12-20', 'Dicky Erfan Septiono', '2022-12-20 14:16:04', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (8, 7, '75000', 1, '2022-12-20', 'Dicky Erfan Septiono', '2022-12-20 14:21:07', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (9, 9, '500000', 1, '2022-12-20', 'Dicky Erfan Septiono', '2022-12-20 14:21:37', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (11, 9, '50000', 1, '2022-12-20', 'Dicky Erfan Septiono', '2022-12-20 14:41:51', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (17, 11, '50000', 0, '2022-12-21', 'Dicky Erfan Septiono', '2022-12-21 09:15:06', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (18, 11, '75000', 0, '2022-12-21', 'Dicky Erfan Septiono', '2022-12-21 09:15:10', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (19, 7, '50000', 1, '2022-12-21', 'Dicky Erfan Septiono', '2022-12-21 10:10:25', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (20, 9, '50000', 1, '2022-12-22', 'Super Admin', '2022-12-22 10:07:43', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (21, 9, '100000', 1, '2022-12-22', 'Super Admin', '2022-12-22 10:08:21', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (22, 9, '50000', 1, '2022-12-22', 'Super Admin', '2022-12-22 10:08:48', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (23, 9, '25000', 1, '2022-12-22', 'Super Admin', '2022-12-22 10:08:55', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (24, 7, '50000', 1, '2022-12-22', 'Dicky Erfan Septiono', '2022-12-22 10:28:25', NULL);
INSERT INTO `detail_taqur` (`id_transaksi`, `id_penabung`, `jml_tabungan`, `status_tabungan`, `tgl_tabungan`, `nama_user`, `tgl_input`, `tgl_update`) VALUES (25, 10, '50000', 1, '2022-12-23', 'Super Admin', '2022-12-23 09:19:43', NULL);


#
# TABLE STRUCTURE FOR: donasi
#

DROP TABLE IF EXISTS `donasi`;

CREATE TABLE `donasi` (
  `id_donasi` int(11) NOT NULL AUTO_INCREMENT,
  `nama_donasi` varchar(100) NOT NULL,
  `deskripsi` text NOT NULL,
  `photo` varchar(255) NOT NULL DEFAULT 'default',
  `status` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_donasi`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4;

INSERT INTO `donasi` (`id_donasi`, `nama_donasi`, `deskripsi`, `photo`, `status`) VALUES (1, 'Galon-Air', 'Donasi untuk pengadaan air minum dalam bentuk galon yang disalurkan kepada orang atau lembaga yang membutuhkan.', 'galonMinum1.jpeg', 1);
INSERT INTO `donasi` (`id_donasi`, `nama_donasi`, `deskripsi`, `photo`, `status`) VALUES (50, 'Kafan Gratis', 'Kegiatan Bakti sosial di desa Sumbersalak Bondowoso', 'kainKafan.jpeg', 1);
INSERT INTO `donasi` (`id_donasi`, `nama_donasi`, `deskripsi`, `photo`, `status`) VALUES (51, 'Tebar-Mushaf', 'Donasi yang terkumpul dipergunakan untuk membeli Al Qur\'an lalu di bagikan kepada warga yang membutuhkannya. ', 'mushaf.jpeg', 1);
INSERT INTO `donasi` (`id_donasi`, `nama_donasi`, `deskripsi`, `photo`, `status`) VALUES (59, 'Operasional', 'untuk biaya operasional di yayasan ', 'donaturTetap.jpeg', 1);
INSERT INTO `donasi` (`id_donasi`, `nama_donasi`, `deskripsi`, `photo`, `status`) VALUES (65, 'Wakaf Masjid', 'Testing', 'default.png', 1);
INSERT INTO `donasi` (`id_donasi`, `nama_donasi`, `deskripsi`, `photo`, `status`) VALUES (66, 'Anak-Yatim', 'Donasi yang di epruntukan untuk anak yatim dan kaum Dhuafa', 'default.png', 1);


#
# TABLE STRUCTURE FOR: lap_jumat
#

DROP TABLE IF EXISTS `lap_jumat`;

CREATE TABLE `lap_jumat` (
  `id_lapJumat` int(11) NOT NULL AUTO_INCREMENT,
  `tanggal` date NOT NULL,
  `lokasi` varchar(256) NOT NULL,
  `target` varchar(256) NOT NULL,
  `distribusi1` varchar(256) NOT NULL,
  `distribusi2` varchar(256) NOT NULL,
  `distribusi3` varchar(256) NOT NULL,
  `donasi1` varchar(256) NOT NULL,
  `donasi2` varchar(256) NOT NULL,
  `donasi3` varchar(256) NOT NULL,
  `donasi4` varchar(256) NOT NULL,
  `donasi5` varchar(256) NOT NULL,
  `status` int(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_lapJumat`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

INSERT INTO `lap_jumat` (`id_lapJumat`, `tanggal`, `lokasi`, `target`, `distribusi1`, `distribusi2`, `distribusi3`, `donasi1`, `donasi2`, `donasi3`, `donasi4`, `donasi5`, `status`) VALUES (1, '2023-01-20', 'Pasar Kotakulon Bondowoso', 'Pedagang, Petugas Kebersihan dan Abang Becak', '80 Box Nasi', '50 Bungkus Nasi', '', 'Ibu Mike 20 Bungkus Nasi', 'Ibu Lily 35 Bungkus Nasi', '', '', '', 1);
INSERT INTO `lap_jumat` (`id_lapJumat`, `tanggal`, `lokasi`, `target`, `distribusi1`, `distribusi2`, `distribusi3`, `donasi1`, `donasi2`, `donasi3`, `donasi4`, `donasi5`, `status`) VALUES (2, '0000-00-00', '', '', '', '', '', '', '', '', '', '', 0);
INSERT INTO `lap_jumat` (`id_lapJumat`, `tanggal`, `lokasi`, `target`, `distribusi1`, `distribusi2`, `distribusi3`, `donasi1`, `donasi2`, `donasi3`, `donasi4`, `donasi5`, `status`) VALUES (3, '2023-01-27', 'Terminal Bondowoso', 'Pengemudi, Tukang Becak dan penumpang', '80 Bungkus Nasi', '', '', 'Hamba Allah 25 Bungkus Nasi', 'Bapak T 30 Minuman Segar', 'Hamba Allah 30 Ayam Crispy', '', '', 1);


#
# TABLE STRUCTURE FOR: sedekah_jumat
#

DROP TABLE IF EXISTS `sedekah_jumat`;

CREATE TABLE `sedekah_jumat` (
  `id_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `nama_transaksi` varchar(100) NOT NULL,
  `jml_transaksi` varchar(100) NOT NULL,
  `tgl_transaksi` date NOT NULL,
  `jenis_transaksi` varchar(100) NOT NULL,
  `nama_user` varchar(100) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `tgl_update` datetime DEFAULT NULL,
  `kode_saldo` int(1) NOT NULL,
  PRIMARY KEY (`id_transaksi`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4;

INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (1, 'Hamba Allah Nangkaan', '256000', '2023-01-13', 'Penerimaan', 'Super Admin', '2023-01-13 09:11:19', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (2, 'Bapak Slamet Tangerang', '200000', '2023-01-15', 'Penerimaan', 'Super Admin', '2023-01-15 09:12:18', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (3, 'Hamba Allah Badean', '50000', '2023-01-17', 'Penerimaan', 'Super Admin', '2023-01-17 07:27:09', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (4, 'Hamba Allah Kademangan', '50000', '2023-01-18', 'Penerimaan', 'Super Admin', '2023-01-18 09:46:29', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (5, 'Hamba Allah Bataan', '100000', '2023-01-20', 'Penerimaan', 'Super Admin', '2023-01-20 09:49:59', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (6, 'Hamba Allah Kajar', '75000', '2023-01-20', 'Penerimaan', 'Super Admin', '2023-01-20 09:50:43', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (7, 'Hamba Allah Blkng Kejaksaan', '100000', '2023-01-20', 'Penerimaan', 'Super Admin', '2023-01-20 09:52:52', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (8, 'Hamba Allah Kalimantan', '100000', '2023-01-20', 'Penerimaan', 'Super Admin', '2023-01-20 14:46:57', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (9, 'Pembelian 80 Nasi Bungkus', '736000', '2023-01-20', 'Pengeluaran', 'Super Admin', '2023-01-20 14:47:52', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (10, 'Hamba Allah Nangkaan', '75000', '2023-01-20', 'Penerimaan', 'Super Admin', '2023-01-20 08:47:30', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (11, 'Hamba Allah Taman Mutiara', '100000', '2023-01-20', 'Penerimaan', 'Admin', '2023-01-26 09:00:20', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (12, 'Hamba Allah Badean', '50000', '2023-01-27', 'Penerimaan', 'Super Admin', '2023-01-27 08:28:30', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (13, 'Hamba Allah Nangkaan', '100000', '2023-01-27', 'Penerimaan', 'Super Admin', '2023-01-27 08:51:56', NULL, 0);
INSERT INTO `sedekah_jumat` (`id_transaksi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (14, 'Hamba Allah Nangkaan', '100000', '2023-01-30', 'Penerimaan', 'Super Admin', '2023-01-30 11:00:00', NULL, 0);


#
# TABLE STRUCTURE FOR: taqur
#

DROP TABLE IF EXISTS `taqur`;

CREATE TABLE `taqur` (
  `id_penabung` int(11) NOT NULL AUTO_INCREMENT,
  `nama_penabung` varchar(100) NOT NULL,
  `alamat` text NOT NULL,
  `status` int(1) NOT NULL,
  PRIMARY KEY (`id_penabung`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4;

INSERT INTO `taqur` (`id_penabung`, `nama_penabung`, `alamat`, `status`) VALUES (7, 'Cindy-Bin-Dicky', 'Badean, Bondowoso', 1);
INSERT INTO `taqur` (`id_penabung`, `nama_penabung`, `alamat`, `status`) VALUES (9, 'Fatimah-Bin-Fulani', 'Tamansari, Bondowoso', 1);
INSERT INTO `taqur` (`id_penabung`, `nama_penabung`, `alamat`, `status`) VALUES (10, 'Bilal-Zaidan', 'Badean, Bondowoso', 1);
INSERT INTO `taqur` (`id_penabung`, `nama_penabung`, `alamat`, `status`) VALUES (11, 'Putri-Jasmine', 'Kademangan, Bondowoso', 0);


#
# TABLE STRUCTURE FOR: transaksi
#

DROP TABLE IF EXISTS `transaksi`;

CREATE TABLE `transaksi` (
  `id_transaksi` int(11) NOT NULL AUTO_INCREMENT,
  `id_donasi` int(11) NOT NULL,
  `nama_transaksi` varchar(100) NOT NULL,
  `jml_transaksi` varchar(100) NOT NULL,
  `tgl_transaksi` date NOT NULL,
  `jenis_transaksi` varchar(100) NOT NULL,
  `nama_user` varchar(100) NOT NULL,
  `tgl_input` datetime NOT NULL,
  `tgl_update` datetime DEFAULT NULL,
  `kode_saldo` int(1) NOT NULL,
  PRIMARY KEY (`id_transaksi`),
  KEY `id_donasi` (`id_donasi`),
  CONSTRAINT `transaksi_ibfk_1` FOREIGN KEY (`id_donasi`) REFERENCES `donasi` (`id_donasi`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb4;

INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (8, 1, 'Hamba Allah Badean', '1000000', '2022-11-07', 'Penerimaan', 'Seorang Admin', '2022-07-14 07:40:59', '2022-07-14 07:52:59', 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (10, 1, 'Pembelian Galon', '450000', '2022-11-13', 'Pengeluaran', 'Seorang Admin', '2022-11-13 08:34:09', NULL, 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (11, 1, 'Hamba Allah Badean', '125000', '2022-11-15', 'Penerimaan', 'Super Admin', '2022-07-15 08:47:03', '2022-12-27 13:24:00', 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (12, 51, 'Hamba Allah Badean', '100000', '2022-12-22', 'Penerimaan', 'Admin', '2022-12-27 04:43:16', NULL, 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (13, 51, 'Hamba Allah Tamansari', '750000', '2022-12-23', 'Penerimaan', 'Admin', '2022-12-27 04:47:56', NULL, 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (14, 50, 'Fulan Bin Fulan', '425000', '2022-12-08', 'Penerimaan', 'Admin', '2022-12-27 04:49:18', NULL, 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (15, 1, 'Hamba Allah Nangkaan', '150000', '2022-12-27', 'Penerimaan', 'Super Admin', '2022-12-27 12:13:20', '2022-12-27 13:23:07', 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (22, 1, 'Saldo Awal Desember 2022', '675000', '2022-12-01', 'Penerimaan', 'Admin', '2022-12-01 00:00:00', NULL, 1);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (24, 51, 'Hamba Allah Badean', '500000', '2022-11-23', 'Penerimaan', 'Super Admin', '2022-12-27 14:28:31', NULL, 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (25, 51, 'Saldo Awal Desember 2022', '500000', '2022-12-01', 'Penerimaan', 'Admin', '2022-12-01 00:00:00', NULL, 1);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (26, 50, 'Hamba Allah Badean', '100000', '2022-11-17', 'Penerimaan', 'Super Admin', '2022-12-27 14:30:09', NULL, 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (27, 50, 'Saldo Awal Desember 2022', '100000', '2022-12-01', 'Penerimaan', 'Admin', '2022-12-01 00:00:00', NULL, 1);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (28, 59, 'Hamba Allah Nangkaan', '100000', '2022-11-17', 'Penerimaan', 'Dicky Erfan Septiono', '2022-12-27 14:56:25', NULL, 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (29, 50, 'Pembelian Stiker', '125000', '2022-12-27', 'Pengeluaran', 'Dicky Erfan Septiono', '2022-12-27 15:19:01', NULL, 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (31, 59, 'Hamba Allah Kotakulon', '500000', '2022-12-27', 'Penerimaan', 'Dicky Erfan Septiono', '2022-12-27 15:22:11', NULL, 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (32, 59, 'Saldo Awal Desember 2022', '100000', '2022-12-01', 'Penerimaan', 'Admin', '2022-12-01 00:00:00', NULL, 1);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (33, 1, 'Saldo Awal Januari 2023', '825000', '2023-01-01', 'Penerimaan', 'Admin', '2023-01-01 00:00:00', NULL, 1);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (34, 50, 'Saldo Awal Januari 2023', '400000', '2023-01-01', 'Penerimaan', 'Admin', '2023-01-01 00:00:00', NULL, 1);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (35, 51, 'Saldo Awal Januari 2023', '1350000', '2023-01-01', 'Penerimaan', 'Admin', '2023-01-01 00:00:00', NULL, 1);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (36, 59, 'Saldo Awal Januari 2023', '600000', '2023-01-01', 'Penerimaan', 'Admin', '2023-01-01 00:00:00', NULL, 1);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (41, 59, 'Hamba Allah Nangkaan', '100000', '2023-01-18', 'Penerimaan', 'Super Admin', '2023-01-18 08:25:44', NULL, 0);
INSERT INTO `transaksi` (`id_transaksi`, `id_donasi`, `nama_transaksi`, `jml_transaksi`, `tgl_transaksi`, `jenis_transaksi`, `nama_user`, `tgl_input`, `tgl_update`, `kode_saldo`) VALUES (42, 50, 'Hamba Allah Nangkaan', '100000', '2023-01-18', 'Penerimaan', 'Super Admin', '2023-01-18 09:37:58', NULL, 0);


#
# TABLE STRUCTURE FOR: user
#

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nama_pengguna` varchar(8) NOT NULL,
  `nama_lengkap` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(256) NOT NULL,
  `level` varchar(10) NOT NULL DEFAULT 'Pengguna',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `email`, `password`, `level`) VALUES (1, 'admin', 'Super Admin', 'Admin@gmail.com', '$2a$12$snBZbN0faYLch4yTVkFD8uJj6ueS7549W.XpIwzAa0zcXPbhBcKTi', 'SuperAdmin');
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `email`, `password`, `level`) VALUES (3, 'dicky', 'Dicky Erfan Septiono', 'dicky@gmail.com', '$2y$10$1n6OYGtyHMI0IqzZHOgvrOqanR1P/6flbzHD2t2zZp4x8d.ZFDZH6', 'Admin');
INSERT INTO `user` (`id`, `nama_pengguna`, `nama_lengkap`, `email`, `password`, `level`) VALUES (4, 'ikhwan', 'Relawan ABY', 'aby@gmail.com', '$2y$10$Uq6JhgMpigol3vdV7Juas.pyo568TsJopWh38FVrs9N7xMYk6J45S', 'Pengguna');


